import React from 'react'

function Page() {
  return (
    <div>
      <h1 className="hello">Hello</h1>
    </div>
  )
}

export default Page
